import React, { useState, useEffect, useLayoutEffect } from 'react';
import '../../components/Dropdown/Dropdown.css';
 
const ShopDropdown = () => {
  const [click, setClick] = useState(false);
  const [top, setTop] = useState(70);   
  const handleClick = () => setClick(!click); 
  var headerHeight = 0, aboveHeaderHeight = 0, lineHeight = 0, headerHeight = 0, totalHeaderHeight = 0;

  const handleResize = () => {
    aboveHeaderHeight = document.getElementById('aboveHeaderMenuContainerId').offsetHeight;
    lineHeight = document.getElementById('lineId').offsetHeight;
    headerHeight = document.getElementById('headerMenuId').offsetHeight;    
    totalHeaderHeight = aboveHeaderHeight + lineHeight + headerHeight;
    //document.getElementById('bannerContainerId').style.top = headerHeight + 'px';

    console.log('Dropdown handleResize ' + aboveHeaderHeight + ' ' + lineHeight + ' ' + headerHeight + ' ' + totalHeaderHeight);

    setTop(totalHeaderHeight);
  };

  useEffect(() => { 
    handleResize();       
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  useLayoutEffect(() => {
    handleResize();
  }, []);   

  return (
    <>  
        <div className='services-dropdown-content' id='myDropdown41' style={{top: top + 'px', display: 'block', width: '1%'}} >             
            <div>   
                <div>				                                 
                    <a href='javascript:void(0)' className='myDropdown41Deal'>Repair</a>
                    <a href='javascript:void(0)' className='myDropdown41Deal'>Rent</a>           
                    <a href='javascript:void(0)' className='myDropdown41Deal'>Recycle</a> 
                </div>         
            </div> 
        </div> 
    </>
  );
}

export default ShopDropdown;
