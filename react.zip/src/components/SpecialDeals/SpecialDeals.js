import "./SpecialDeals.css";
import axios from "axios";
import { useState, useEffect, useLayoutEffect, useRef } from "react"; 
 
const SpecialDeals = () => {   
    
    const [specialDeals, setSpecialDeals] = useState([]);
    const [dot, setDot] = useState([]);
    const [page, setPage] = useState(0);
    const { height, wWidth } = useWindowDimensions();
    var blackFridayDeals = '', blackFridayDealDot = '', blackFridayDeal_total_columns = 0, blackFridayDealPages = 0;//var windowWidth = 0; //, host = 'http://ur1stop.com/';
    var host = 'http://ur1stop.com/', blackFridayDealDotMargin = '', dotClass = '', pSDI = 0, i = 0, dataArray;
    var  specialDealsArrowLeftWidth = '', blackFridayDealIndicatorsWidth = '', specialDealsArrowRightWidth = '';
    //const ref = useRef();    
    //const size = useDimensions(ref);

    const getSpecialDeals = async (page) => {   
        const { innerWidth: width, innerHeight: height } = window;
        const { data } = await axios.get(            
            `http://127.0.0.1/blackFridayDeals.php?width=${width}&page=${page}`
        );                     
         
        dataArray = data.split("|||");               blackFridayDealDot = '';                   blackFridayDeals = dataArray[0];              
              
        if(width > 1000) { blackFridayDeal_total_columns = 4; }  if(width > 580 && width <= 1000) { blackFridayDeal_total_columns = 3; }
        if(width <= 580) { blackFridayDeal_total_columns = 2; }  

        blackFridayDealPages = Math.floor( Number(dataArray[1]) / blackFridayDeal_total_columns);

        //console.log("SpecialDeals page " + `http://127.0.0.1/blackFridayDeals.php?width=${width}&page=${page}` + ' ' + page + ' ' + width + ' ' + blackFridayDeal_total_columns + ' ' + blackFridayDealPages);

        if(width > 1000) 
        { 
          blackFridayDealDotMargin = 'margin: 0% 3%'; 
          specialDealsArrowLeftWidth = '1%';
          blackFridayDealIndicatorsWidth = '10%';
          specialDealsArrowRightWidth = '1%';
        }                                 
        if(width > 480 && width <= 1000)    
        { 
            blackFridayDealDotMargin = 'margin: 0% 3%';       
            specialDealsArrowLeftWidth = '5%';
            blackFridayDealIndicatorsWidth = '60%';
            specialDealsArrowRightWidth = '5%';
        }
        if(width <= 480)                    
        { 
            blackFridayDealDotMargin = 'margin: 0% 5%'; 
                              
            //blackFridayDealsCaptionFontWeight = 'font-weight: normal'; 
            //blackFridayDealsCaptionFontSize = 'font-size: 0.8em';                 
            //blackFridayDealsCaptionWidth = 'width: 99%';                   
             
            specialDealsArrowLeftWidth = '5%';
            blackFridayDealIndicatorsWidth = '80%';
            specialDealsArrowRightWidth = '5%';
        } 

        for(i = 0; i < blackFridayDealPages; i++)
        {                  
            dotClass = ''; if(page == i) dotClass = 'present';
            blackFridayDealDot = blackFridayDealDot + "<span id='blackFridayDealDot_"+i+"' class='blackFridayDealDot "+dotClass+"' style='"+blackFridayDealDotMargin+"' onclick=blackFridayDeals("+i+")></span>";
        } 

        //$('.blackFridayDealIndicators').html(blackFridayDealDot);                       $('.blackFridayDealIndicators').show(); 
        //$('.blackFridayDealDot').removeClass('present');                                $('#blackFridayDealDot_'+page).addClass('present');
          
        //blackFridayDealPagesLoaded = 1;       

        //$('.specialDealsArrowLeft').show(); $('.specialDealsArrowRight').show();
        //if(page == 0) { $('.specialDealsArrowLeft').hide(); } if(page == blackFridayDealPages - 1) { $('.specialDealsArrowRight').hide(); }
        //if(blackFridayDealPages == 1) { $('.specialDealsArrowLeft').hide(); $('.specialDealsArrowRight').hide(); } 

        pSDI = page; 
        setSpecialDeals(blackFridayDeals);
        setDot(blackFridayDealDot); 
    };  

    useEffect(() => {     
      getSpecialDeals(0);         

      const timer = setInterval(() => {
        pSDI++; if(pSDI < blackFridayDealPages) { } else pSDI = 0;          

          //console.log('topdeals setTimeout pSDI ' + pSDI);

          getSpecialDeals(pSDI);   
      }, 7000);      
                        
      function handleResize() {          
          getSpecialDeals();
        }   
        window.addEventListener("resize", handleResize);
        return () => { window.removeEventListener("resize", handleResize); clearTimeout(timer); }
    }, []);      

    //console.log('topdeals data ' + topDeals);

    const rawMarkup = () => {   
      return { __html: specialDeals };
    }; 

    const rawMarkupDot = () => {   
      return { __html: dot };
    }; 

    return (             
        <div className="blackFridayDealsContainer">    
            <div className="blackFridayDealsCaptionDiv"> 
                <div className="blackFridayDealsCaption" style={{ width: wWidth <= 580 ? '99%': '90%', fontSize: wWidth <= 580 ? '0.8em': '1em', fontWeight: wWidth <= 580 ? 'normal': 'bold' }}> 
                    Our Special Deals
                </div>         
            </div> 
            <div className="blackFridayDeals" style={{ margin: wWidth > 1000 ? '0% 5%': '0% 1%' }} dangerouslySetInnerHTML={rawMarkup()} />   
            <div className="blackFridayDealsDiv">
                <div className="specialDealsArrowLeft" style={{ width: specialDealsArrowLeftWidth, 
                    display: page == 0 ? 'none': 'block', display: blackFridayDealPages == 1 ? 'none': 'block' }}>   
                    <img src={`${host}images/Site_Arrow-Icons_Left-Orange.png`} width="100%" alt="" />								  
                </div>
                <div className="blackFridayDealIndicators" style={{ width: blackFridayDealIndicatorsWidth }} dangerouslySetInnerHTML={rawMarkupDot()} />
                <div className="specialDealsArrowRight" style={{ specialDealsArrowRightWidth, display: blackFridayDealPages == 1 ? 'none': 'block' }}>   
                    <img src={`${host}images/Site_Arrow-Icons_Right-Orange.png`} width="100%" alt="" />								  
                </div>						        	
            </div>            
        </div> 
    );
};

function useDimensions(targetRef) {
    const getDimensions = () => {
      return {
        width: targetRef.current ? targetRef.current.offsetWidth : 0,
        height: targetRef.current ? targetRef.current.offsetHeight : 0
      };
    };
  
    const [dimensions, setDimensions] = useState(getDimensions);
    const [windowDimensions, setWindowDimensions] = useState(getWindowDimensions());

    const handleResize = () => {
      setDimensions(getDimensions());
      setWindowDimensions(getWindowDimensions());
    };
  
    useEffect(() => {
      window.addEventListener("resize", handleResize);
      return () => window.removeEventListener("resize", handleResize);
    }, []);
  
    useLayoutEffect(() => {
      handleResize();
    }, []);
    return dimensions;
}

function getWindowDimensions() {
  const { innerWidth: wWidth, innerHeight: height } = window;
  return {
    wWidth,
    height
  };
}

function useWindowDimensions() {
  const [windowDimensions, setWindowDimensions] = useState(getWindowDimensions());

  useEffect(() => {
    function handleResize() {
      setWindowDimensions(getWindowDimensions());
    }

    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  return windowDimensions;
}

export default SpecialDeals;