import "./TopDeals.css";
import axios from "axios";
import { useState, useEffect, useLayoutEffect, useRef } from "react"; 
import {Link} from "react-router-dom"; 
 
const TopDeals = () => {   
    
    const [topDeals, setTopDeals] = useState([]);
    const { height, wWidth } = useWindowDimensions();
    //var windowWidth = 0; //, host = 'http://ur1stop.com/';
    //const ref = useRef();    
    //const size = useDimensions(ref);

    const getTopDeals = async () => {   
        const { innerWidth: width, innerHeight: height } = window;
        const { data } = await axios.get(            
            `http://127.0.0.1/ruaaTopDeals.php?width=${width}`
        );                     
        console.log('component topdeals data ' + `http://127.0.0.1/ruaaTopDeals.php?width=${width}` + ' ' + wWidth);        
        setTopDeals(data);
    };  

    useEffect(() => {      
        getTopDeals();                     
        function handleResize() {
          getTopDeals();
        }   
        window.addEventListener("resize", handleResize);
        return () => window.removeEventListener("resize", handleResize);
    }, []);      

    //console.log('topdeals data ' + topDeals);

    const rawMarkup = () => {   
      return { __html: topDeals };
    }; 

    return (  
      <div>
        <div className="topDealsContainer">   
          <div className="topDealsCaption"> 
            <h1>Top Deals</h1>        
          </div> 
          <div className="topDeals" dangerouslySetInnerHTML={rawMarkup()} style={{ margin: wWidth > 1000 ? '0% 5%': '0% 1%' }} />                 
        </div> 
        <Link to='/products/page=1&type=&subType=&brand=&minPrice=&maxPrice=&sortBy=&cpu=&ram=&keyword=&itemCondition=&appleWindows=&rentalSearch='><div className="viewMoreButon">View more</div></Link>
      </div> 
    );
};

function useDimensions(targetRef) {
    const getDimensions = () => {
      return {
        width: targetRef.current ? targetRef.current.offsetWidth : 0,
        height: targetRef.current ? targetRef.current.offsetHeight : 0
      };
    };
  
    const [dimensions, setDimensions] = useState(getDimensions);
    const [windowDimensions, setWindowDimensions] = useState(getWindowDimensions());

    const handleResize = () => {
      setDimensions(getDimensions());
      setWindowDimensions(getWindowDimensions());
    };
  
    useEffect(() => {
      window.addEventListener("resize", handleResize);
      return () => window.removeEventListener("resize", handleResize);
    }, []);
  
    useLayoutEffect(() => {
      handleResize();
    }, []);
    return dimensions;
}

function getWindowDimensions() {
  const { innerWidth: wWidth, innerHeight: height } = window;
  return {
    wWidth,
    height
  };
}

function useWindowDimensions() {
  const [windowDimensions, setWindowDimensions] = useState(getWindowDimensions());

  useEffect(() => {
    function handleResize() {
      setWindowDimensions(getWindowDimensions());
    }

    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  return windowDimensions;
}

export default TopDeals;