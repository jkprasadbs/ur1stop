import React, { useState, useEffect, useLayoutEffect } from 'react';
import axios from "axios";
import '../../components/Dropdown/Dropdown.css';
import { Link } from 'react-router-dom';

const SearchDropdown = (props) => {
    const [click, setClick] = useState(false);
    const [top, setTop] = useState({top: 0, left: 0, width: 0}); 
    const [searchResults, setSearchResults] = useState('');   
    const handleClick = () => setClick(!click); 
    var headerHeight = 0, aboveHeaderHeight = 0, lineHeight = 0, headerHeight = 0, totalHeaderHeight = 0, da = '', jsonData, i = 0;

    const handleResize = () => {
        aboveHeaderHeight = document.getElementById('aboveHeaderMenuContainerId').offsetHeight;
        lineHeight = document.getElementById('lineId').offsetHeight;
        headerHeight = document.getElementById('headerMenuId').offsetHeight;    
        totalHeaderHeight = aboveHeaderHeight + lineHeight + headerHeight;
        //document.getElementById('bannerContainerId').style.top = headerHeight + 'px';
        //console.log('SearchDropdown handleResize ' + aboveHeaderHeight + ' ' + lineHeight + ' ' + headerHeight + ' ' + totalHeaderHeight);
 
        const getSearchResultsDimensions = () => {
            var rect = document.getElementById('search').getBoundingClientRect(); 
            return { 
              top: rect.bottom,              
              left: rect.left,
              width: document.getElementById('search').offsetWidth
            }
        };   

        setTop(getSearchResultsDimensions);
    };

    const search = async () => 
    { 
        //console.log('SearchDropdown url ' + `http://127.0.0.1/newSearchBarProducts.php?keyword=${props.keyword}`);
        const { data } = await axios.get(`http://127.0.0.1/newSearchBarProducts.php?keyword=${props.keyword}`);   
        da = ''; jsonData = data;

        if(jsonData.products.length > 0) { da = da + "<a href='javascript:void(0)' style='font-size: 14px; font-weight: bold;'>NEW</a>"; }            
        for(i = 0; i < jsonData.products.length; i++) 
        { da = da + "<a href='"+jsonData.products[i].On_Market+"' id='"+jsonData.products[i].Id+"' style='font-size: 15px; font-weight: normal; text-decoration: none; color: black;' desc='"+jsonData.products[i].desc+"'>"+jsonData.products[i].name+"</a>"; }  

        if(jsonData.refurbProducts.length > 0) 
        { da = da + "<a href='javascript:void(0)' style='font-size: 14px; font-weight: bold;'>REFURBISHED</a>"; } 
        for(i = 0; i < jsonData.refurbProducts.length; i++) 
        { da = da + "<a href='"+jsonData.refurbProducts[i].On_Market+"' id='"+jsonData.refurbProducts[i].Id+"' style='font-size: 15px; font-weight: normal; text-decoration: none; color: black;' desc='"+jsonData.refurbProducts[i].desc+"'>"+jsonData.refurbProducts[i].name+"</a>"; } 
 
        //var isIE11 = !!window.MSInputMethodContext && !!document.documentMode; if(isIE11) { $("#myDropdown200").css('position', 'relative'); } 
        //sTop = $("#searchMobile").parent().offset().top + $("#searchMobile").parent().height(); //+ 5
        //if(mobileView == 1) { sTop = $("#searchMobile").parent().offset().top + $("#searchMobile").parent().height() + 5; } 
        //console.log('$(searchMobile).offset().top  ' + $("#searchMobile").parent().offset().top + ' $(searchMobile).height() ' + $("#searchMobile").parent().height()+ ' sTop '+ sTop);  
        //$("#myDropdown200").css('width', $(window).width());             
         
        setSearchResults(da); 
    };   

    useEffect(() => { 
        handleResize();       
        search();
        window.addEventListener("resize", handleResize);
        return () => window.removeEventListener("resize", handleResize);
    }, []);

    useLayoutEffect(() => { handleResize(); }, []);   

    const rawMarkup = () => { return { __html: searchResults }; }; 

    return (
        <> 
            <div className='dropdown-content' id='myDropdown200' dangerouslySetInnerHTML={rawMarkup()} 
            style={{position: 'fixed', top: top.top + 'px', left: top.left, width: top.width}} />    
        </>
    );
}

export default SearchDropdown;