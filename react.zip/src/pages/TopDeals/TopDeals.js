import "../../components/TopDeals/TopDeals.css";
import axios from "axios";
import { useState, useEffect } from "react"; 
import { useLocation, useParams } from "react-router-dom"; 
 
const TopDeals = (state) => 
{
    const [topDeals, setTopDeals] = useState([]);
    const { height, wWidth } = useWindowDimensions();   
    //const location = useLocation();
    const params = useParams();
    const [locationState, setLocationState] = useState({id: 0});
    const getTopDeals = async () => 
    { 
        const { innerWidth: width, innerHeight: height } = window; 
        console.log('page topdeals params ' +  `http://127.0.0.1/getHomeProductImage_test.php?width=${width}&topDealsFlag=${params.id}`);        
        const { data } = await axios.get(`http://127.0.0.1/getHomeProductImage_test.php?width=${width}&topDealsFlag=${params.id}`);         
        setTopDeals(data);   
    };

    useEffect(() => 
    {    
        //if(location.state) { let _state = location.state; setLocationState(_state);
            getTopDeals();    
        //}        
                        
        function handleResize() { getTopDeals(); }   
        window.addEventListener("resize", handleResize);
        return () => window.removeEventListener("resize", handleResize);
    }, []);       

    //console.log('page topdeals data ' + wWidth + ' ' + locationState.id); 
   
    const rawMarkup = () => { return { __html: topDeals }; }; 
    return ( <div style = {{ position:'relative', top: '80px' }} dangerouslySetInnerHTML={rawMarkup()} />  );
}; 

function getWindowDimensions() {
    const { innerWidth: wWidth, innerHeight: height } = window;
    return {
      wWidth,
      height
    };
  }
  
  function useWindowDimensions() {
    const [windowDimensions, setWindowDimensions] = useState(getWindowDimensions());
  
    useEffect(() => {
      function handleResize() {
        setWindowDimensions(getWindowDimensions());
      }
  
      window.addEventListener("resize", handleResize);
      return () => window.removeEventListener("resize", handleResize);
    }, []);
  
    return windowDimensions;
  }

export default TopDeals;