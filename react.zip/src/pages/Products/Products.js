import "./Products.css";
import Pagination from '../../pages/Pagination/Pagination';
import axios from "axios";
import {useState, useEffect, useMemo } from "react"; 
import {useParams, useNavigate, Link, useLocation} from "react-router-dom"; 
import {isMobile} from 'react-device-detect'; 

let PageSize = 32;
 
const Products = () => 
{
    const [products, setProducts] = useState([]);                                       const [total, setTotal] = useState(10);
    const { height, wWidth } = useWindowDimensions();                                   const params = useParams();

    const [titleDisplay, setTitleDisplay] = useState('');                    const [itemPanelBannerSrc, setItemPanelBannerSrc] = useState('');
    const [itemPanelBannerCategory, setItemPanelBannerCategory] = useState('');         

    const [brandHtml, setBrandHtml] = useState('');                              const [subTypeHtmlValue, setSubTypeHtml] = useState('');
    const [priceHtml, setPriceHtml] = useState('');
                                     const [procValue, setProcValue] = useState('');
    const [ramValue, setRamValue] = useState('');                                     const [osValue, setOsValue] = useState('');
    const [conValue, setConValue] = useState('');                                     const [sortValue, setSortValue] = useState('');

    const [page, setPage] = useState(1);                  const [brand, setBrand] = useState('');
    const [minPrice, setMinPrice] = useState(''); const [maxPrice, setMaxPrice] = useState('');
    const [sortBy, setSortBy] = useState('');     const [cpu, setCPU] = useState('');           const [ram, setRAM] = useState(''); 
    const [keyword, setKeyword] = useState('');   const [itemCondition, setItemCondition] = useState(''); 
    const [appleWindows, setAppleWindows] = useState('');   const [rentalSearch, setRentalSearch] = useState(''); 
    const [subType, setSubType] = useState('');                                    
    const [brands, setBrands] = useState([]);                                       const [prices, setPrices] = useState([]);
    const [dataLength, setDataLength] = useState(1);                                const location = useLocation();
    const [items, setItems] = useState([]);                                         const navigate = useNavigate();
     
    let limit = 32;                                                                 var randomString = '', flag = 0, hFlag = 0, localParams = ''; 

    var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    var charactersLength = characters.length; 

    const handleChange = (e) => {
        console.log('products handleChange '+ e.target.id + ' ' + e.target.className + ' ' + e.target.value);           
        //setCurrentPage(0);
        var vPage = 1, vType = '';
        if(e.target.className == 'type') 
        {         
            if(e.target.value == 'selectAll')  { setType(''); vType = ''; } //setTypeValue('');
            else 
            {   setType("'"+e.target.value+"'"); vType = "'"+e.target.value+"'";
                console.log('products handleChange 1 ' + e.target.id + ' ' + e.target.className + ' ' + e.target.value);  
            } //setTypeValue(e.target.value); 
        } 
        setPage(1); 
        let path = '/products/page='+vPage+'&type='+vType+'&subType=&brand=&minPrice=&maxPrice=&sortBy=&cpu=&ram=&keyword=&itemCondition=&appleWindows=&rentalSearch=';                    
        redirect(path);
    };  

    const [type, setType] = useState(() => 
    {
        var tParams = params.id;                                    var paramArray = tParams.split('&');       
        var singleParamArray = paramArray[1].split('=');            const initialState = singleParamArray[1];
        console.log('type initialState '+ initialState);            return initialState;
    }); 

    const [currentPage, setCurrentPage] = useState(() => 
    {
        var tParams = params.id;                                    var paramArray = tParams.split('&');       
        var singleParamArray = paramArray[0].split('=');            const initialState = Number(singleParamArray[1]);
        console.log('currentPage initialState '+ initialState);     return initialState;
    });    

    const getProducts = async () => 
    { 
        const { innerWidth: width, innerHeight: height } = window;  var tParams =  '';      
        randomString = ''; for ( var i = 0; i < 10; i++ ) { randomString += characters.charAt(Math.floor(Math.random() * charactersLength)); }

        if(flag == 1) { tParams = localParams; } else { tParams = params.id;  }                   
        var paramArray = tParams.split('&'), jsonData;       var param = 'width='+width;
        for(var i = 0; i < paramArray.length; i++)
        {
            var singleParamArray = paramArray[i].split('='); //if(flag == 0) { hFlag = 1; setCurrentPage(Number(singleParamArray[1])); }
            if(singleParamArray[0] == 'page')           { param = param + '&page='+singleParamArray[1]; }
            if(singleParamArray[0] == 'type')           { param = param + '&type='+singleParamArray[1]; }
            if(singleParamArray[0] == 'subType')        { param = param + '&subType='+singleParamArray[1]; }
            if(singleParamArray[0] == 'brand')          { param = param + '&brand='+singleParamArray[1]; }
            if(singleParamArray[0] == 'minPrice')       { param = param + '&minPrice='+singleParamArray[1]; }
            if(singleParamArray[0] == 'maxPrice')       { param = param + '&maxPrice='+singleParamArray[1]; }
            if(singleParamArray[0] == 'sortBy')         { param = param + '&sortBy='+singleParamArray[1]; }
            if(singleParamArray[0] == 'cpu')            { param = param + '&cpu='+singleParamArray[1]; }
            if(singleParamArray[0] == 'ram')            { param = param + '&ram='+singleParamArray[1]; }
            if(singleParamArray[0] == 'keyword')        { param = param + '&keyword='+singleParamArray[1]; }
            if(singleParamArray[0] == 'itemCondition')  { param = param + '&itemCondition='+singleParamArray[1]; }
            if(singleParamArray[0] == 'appleWindows')   { param = param + '&appleWindows='+singleParamArray[1]; }
            if(singleParamArray[0] == 'rentalSearch')   { param = param + '&rentalSearch='+singleParamArray[1]; } 
        }               
        param = param + '&r='+randomString;        

        //var url = `http://127.0.0.1/products_test.php?page=${page}&type=${type}&brand=${brand}&thisType=${thisType}&minPrice=${minPrice}&maxPrice=${maxPrice}&sortBy=${sortBy}&cpu=${cpu}&ram=${ram}&keyword=${keyword}&itemCondition=${itemCondition}&appleWindows=${appleWindows}&rentalSearch=${rentalSearch}&width=${width}&subType=${subType}`;
        var url = `http://127.0.0.1/products_test.php?`+param;
        const { data } = await axios.get(url);         
        var splitData = data.split("|||");                                              jsonData = JSON.parse(splitData[0].trim());    
        setProducts(splitData[1].trim());                                               setTotal(jsonData.Total); //
        console.log('page products url ' +  url + ' ' + jsonData.Total);
        setDataLength(jsonData.Total);                                                  flag = 0;        var tDisplay = ''; 
        if(type == '')  
        {
            tDisplay = 'keywordTitleproductTitleconditionTitlepriceTitlesortTitleprocessorTitleramTitleosTitleprocessorDropdownramDropdownosDropdown'; 
        }
        else if(type.indexOf("'gaming'") > -1 || type.indexOf("'notebook'") > -1 || type.indexOf("'desktop'") > -1 || type.indexOf("'tablet'") > -1 
        || type.indexOf("'aio'") > -1) { }   
        else { setCPU(''); setRAM(''); setAppleWindows(''); tDisplay = 'keywordTitleproductTitleconditionTitlepriceTitlesortTitle'; } 
         
        if(type.indexOf("'notebook'") > -1   || type.indexOf("'desktop'") > -1        || type.indexOf("'tablet'") > -1     || type.indexOf("'monitor'") > -1
        || type.indexOf("'tv'") > -1         || type.indexOf("'gamingConsole'") > -1  || type.indexOf("'harddrive'") > -1  || type.indexOf("'inputDevice'") > -1
        || type.indexOf("'cpu'") > -1        || type.indexOf("'inputDevice'") > -1    || type.indexOf("'memory'") > -1     || type.indexOf("'printer'") > -1
        || type.indexOf("'projector'") > -1  || type.indexOf("'accessory'") > -1      || type.indexOf("'videoGames'") > -1 || type.indexOf("'graphicCard'") > -1
        || type.indexOf("'accessory'") > -1) 
        {                
            console.log("products.js showResults newType contains 'notebook' || 'desktop' || 'tablet' || 'monitor' || 'tv' || 'gamingConsole'");                               
            tDisplay =  tDisplay + 'subTypeTitlesubTypeDropdown';
        } else { setSubType(''); }  

        setTitleDisplay(tDisplay);  

        //setCurrentPage(page);

        /* var inner_div_class = Math.floor(Math.random() * 10000000), inner_div_id = Math.floor(Math.random() * 10000000), te = "this.handleChange = handleChange.bind(this)"; 
        var innerHtml = "<div><input type='checkbox' value='selectAll' class='brand' onchange='this.disabled=true; onoverlay(); selectAll(this);' id='selectAll_"+inner_div_class+"'>&nbsp;&nbsp;Clear All</div>";
        for(var i = 0; i < jsonData.brand.length; i++)
        { 
            inner_div_id = Math.floor(Math.random() * 10000000);                 
            innerHtml = innerHtml + "<div>";             
            //if (showParticularBrand != jsonData.brand[i].MGD) {
                innerHtml = innerHtml + "<input type='checkbox' value='"+jsonData.brand[i].ManufacturerGlobalDescr+"' className='brand' id="+inner_div_id+" onChange="+te+">&nbsp;&nbsp;"+jsonData.brand[i].MGD+"</div>";                                       
            //} else {
                //innerHtml = innerHtml + "<input type='checkbox' value='"+jsonData.brand[i].ManufacturerGlobalDescr+"' class='brand' onchange='this.disabled=true; onoverlay(); searchBrand(this);' id="+inner_div_id+" checked>&nbsp;&nbsp;"+jsonData.brand[i].MGD+"</div>"; 
                //$('#bran').prop("checked", true); //showParticularBrand = ''; }
        }           
        setBrandHtml(innerHtml); */

        setBrands(jsonData.brand);

        var priceIH = '', priceRangeText = '', cur = '$', arrayIndex = 0;
        var priceRangeId = ['clearAll', 'p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7', 'p8', 'p9', 'p10', 'p11', 'p12'];
        var priceRangeParam = ['clearAll', 'underQua', 'quaToHalf', 'halfToOne', 'oneToTwo', 'twoToThree', 'threeToFour', 'fourToFive', 'fiveToSix', 
'sixToSeven', 'sevenToEight', 'eightToNine', 'aboveNine'];
        var priceRangeFrom = [[0, 0], [0, 0], [25, 1875], [50, 3750], [100, 7500], [200, 15000], [300, 22500], [400, 30000], [500, 37500], [600, 45000], [700, 52500], [800, 60000], [900, 67500]];
        var priceRangeTo = [[0, 0], [25, 1875], [50, 3750], [100, 7500], [200, 15000], [300, 22500], [400, 30000], [500, 37500], [600, 45000], [700, 52500], [800, 60000], [900, 67500], [10000, 750000]];

        /* for(var pri = 0; pri < priceRangeId.length; pri++)
        {
            var onChangeCode = "$(&quot;.prices&quot;).prop(&quot;checked&quot;, false);$(&quot;#"+priceRangeId[pri]+"&quot;).prop(&quot;checked&quot;, true);filterByPrice(&quot;"+priceRangeParam[pri]+"&quot;);priceResetSession()";

            if(pri == 0) { priceRangeText = 'Clear All'; }
            else if(pri == 1) { priceRangeText = 'Under ' + cur+priceRangeTo[pri][arrayIndex]; }
            else if(pri == 12) { priceRangeText = cur+priceRangeFrom[pri][arrayIndex] + ' & Above'; } //
            else { priceRangeText = cur+priceRangeFrom[pri][arrayIndex] + ' to ' + cur+priceRangeTo[pri][arrayIndex]; }

            priceIH=priceIH+"<div><input type='checkbox' id="+priceRangeId[pri]+" class='prices' onchange='"+onChangeCode+"'>&nbsp;&nbsp;"+priceRangeText+"</div>";             
        }
        priceIH=priceIH+"<div><input type=number style='font-size: 12px' id=minprice name=minprice placeholder=Min min=0 max=100000 onkeydown='javascript: return event.keyCode == 69 ? false : true'>&nbsp;&nbsp;<input type=number style='font-size: 12px' id=maxprice name=maxprice placeholder=Max min=0 max=100000 onkeydown='javascript: return event.keyCode == 69 ? false : true' onfocusout='getProductsForPrice();'></div>";
        setPriceHtml(priceIH); */

        const priceRange = 
        [   { priceRangeId: 'clearAll', priceRangeText: 'Clear All' },
            { priceRangeId: 'p1', priceRangeText: 'Under $25' },
            { priceRangeId: 'p2', priceRangeText: '$25 to $50' },
            { priceRangeId: 'p3', priceRangeText: '$$50 to $100' },
            { priceRangeId: 'p4', priceRangeText: '$100 to $200' },
            { priceRangeId: 'p5', priceRangeText: '$200 to $300' },
            { priceRangeId: 'p6', priceRangeText: '$300 to $400' },
            { priceRangeId: 'p7', priceRangeText: '$400 to $500' },
            { priceRangeId: 'p8', priceRangeText: '$500 to $600' },
            { priceRangeId: 'p9', priceRangeText: '$600 to $700' },
            { priceRangeId: 'p10', priceRangeText: '$700 to $800' },
            { priceRangeId: 'p11', priceRangeText: '$800 to $900' },
            { priceRangeId: 'p12', priceRangeText: '$900 & Above' }  
        ];
        setPrices(priceRange);

        setItemPanelBannerSrc('https://www.ur1stop.com/images/banners/promo3.jpg');
        if(!isMobile) 
        { 
            if(type == '')
            {
                //$('.productTitle').show(); $('#myDropdown150').show(); 
                if(brand == "'APPLE'")
                { setItemPanelBannerSrc('https://www.ur1stop.com/images/topDeals/refurbBanner.png'); setItemPanelBannerCategory('refurbApple'); } 

                if(itemCondition == 'refurbished')
                { setItemPanelBannerSrc('https://www.ur1stop.com/images/topDeals/refurbBanner.png'); setItemPanelBannerCategory('refurbWindows'); }
            }
            else
            { 
                if(type == "'notebook'")
                { setItemPanelBannerSrc('https://www.ur1stop.com/images/topDeals/notebookBanner.png'); setItemPanelBannerCategory('notebook'); }

                if(type == "'desktop'")
                { setItemPanelBannerSrc('https://www.ur1stop.com/images/topDeals/desktopBanner.png'); setItemPanelBannerCategory('desktop'); }
                
                if(type == "'aio'")
                { setItemPanelBannerSrc('https://www.ur1stop.com/images/topDeals/aioBanner.png'); setItemPanelBannerCategory('aio'); }

                if(type == "'monitor'")
                { setItemPanelBannerSrc('https://www.ur1stop.com/images/topDeals/monitorBanner.png'); setItemPanelBannerCategory('monitor'); }

                if(type == "'accessory'")
                { setItemPanelBannerSrc('https://www.ur1stop.com/images/topDeals/accessoryBanner.png'); setItemPanelBannerCategory('accessory'); }
                
                if(type == "'tv'")
                { setItemPanelBannerSrc('https://www.ur1stop.com/images/topDeals/tvBanner.png'); setItemPanelBannerCategory('tv'); }

                if(type == "'tablet'")
                { setItemPanelBannerSrc('https://www.ur1stop.com/images/topDeals/tabletBanner.png'); setItemPanelBannerCategory('tablet'); }

                if(type == "'gaming'")
                { setItemPanelBannerSrc('https://www.ur1stop.com/images/banners/gamingBanner.png'); setItemPanelBannerCategory('gaming'); }

                if(type == "'graphicCard'")
                { setItemPanelBannerSrc('https://www.ur1stop.com/images/topDeals/accessoryBanner.png'); setItemPanelBannerCategory('graphicCard'); }

                if(type == "'phone'")
                { setItemPanelBannerSrc('https://ur1stop.com/images/ruaa/tMobileBanner.png'); setItemPanelBannerCategory('phone'); }
            } 
        }      
    };

    useEffect(() => 
    {   getProducts();                                      window.scrollTo(0, 0);                  function handleResize() { getProducts(); }   
        window.addEventListener("resize", handleResize);    return () => window.removeEventListener("resize", handleResize);
    }, []);             

    console.log('products page ' +page); var lFlag = 0;
    
    //useEffect(() => { console.log('Location changed ' + JSON.stringify(location) + ' ' + location.pathname); 
    //if(!location.pathname.includes('page=1')) { getProducts(); window.scrollTo(0, 0); } lFlag = 1; setCurrentPage(page); }, [location]);
    const currentTableData = useMemo(() => {          

        console.log('products currentTableData params.id ' + params.id);

        //if(currentPage > 0) //lFlag==0 &&
        //{
            let path = '/products/page='+currentPage+'&type='+type+'&subType=&brand=&minPrice=&maxPrice=&sortBy=&cpu=&ram=&keyword=&itemCondition=&appleWindows=&rentalSearch=';         
            redirect(path);
                         
        //lFlag = 1; }
    }, [currentPage]);

    function redirect(path) {
        
        console.log('products redirect path ' + path + ' params.id ' + params.id);
        if(!path.includes(params.id))
        {
            console.log('products currentTableData path ' +path + ' params.id ' + params.id);
            window.location.href = path;
        }   
    }

    const rawMarkup = () => { return { __html: products }; };     
    return (  
        <div className="container">
             <div className="optionPanel">  
                <div className="closeOption" onclick="hideMobileMenu();">X</div>
                <div className="optionTitle mobileMainMainLink" onclick="showMobileMenu(1);">Main Menu</div>
                <div id="deviceCategory" className="optionTitle keywordTitle" style={{position: 'relative', display: 'none' }}></div> 
                <div className="optionTitle productTitle" style={{ display: titleDisplay.includes('productTitle') ? 'block' : 'none' }}>Type</div>
                <div className="productsDropdown" id="myDropdown150">   
                  <div>
                      <input type="checkbox" value="selectAll" className="type" id="selectAllType" onChange={(e) => { handleChange(e); }} checked={ type.replaceAll('\'', '').includes('selectAll') ? true : false }/>
                      &nbsp;&nbsp;Clear All
                  </div>
                  <div>
                      <input type="checkbox" value="gaming" className="type" id="gaming" onChange={(e) => { handleChange(e); }} checked={ type.replaceAll('\'', '') == 'gaming' ? true: false } />
                      &nbsp;&nbsp;Gaming Computer
                  </div>
                  <div>
                      <input type="checkbox" value="gamingConsole" className="type" id="gamingConsole" onChange={(e) => { handleChange(e); }} checked={ type.replaceAll('\'', '').includes('gamingConsole') ? true : false } />
                      &nbsp;&nbsp;Gaming Console
                  </div> 
                  <div>
                      <input type="checkbox" value="videoGames" className="type" id="videoGames" onChange={(e) => { handleChange(e); }} checked={ type.replaceAll('\'', '').includes('videoGames') ? true : false } />
                      &nbsp;&nbsp;Video Games
                  </div> 
                  <div>
                      <input type="checkbox" value="notebook" className="type"  id="notebook" onChange={(e) => { handleChange(e); }} checked={ type.replaceAll('\'', '').includes('otebook') ? true : false } />
                      &nbsp;&nbsp;Notebook
                  </div>
                  <div>
                      <input type="checkbox" value="desktop" class="type" id="desktop" onChange={(e) => { handleChange(e); }} checked={ type.replaceAll('\'', '').includes('desktop') ? true : false } />
                      &nbsp;&nbsp;Desktop
                  </div>  
                  <div>
                      <input type="checkbox" value="aio" className="type" id="aio" onChange={(e) => { handleChange(e); }} checked={ type.replaceAll('\'', '').includes('aio') ? true : false } />
                      &nbsp;&nbsp;All in one
                  </div> 
                  <div>
                      <input type="checkbox" value="tablet" className="type" id="tablet" onChange={(e) => { handleChange(e); }} checked={ type.replaceAll('\'', '').includes('tablet') ? true : false } />
                      &nbsp;&nbsp;Tablet
                  </div> 
                  <div>
                      <input type="checkbox" value="phone" className="type" id="phone" onChange={(e) => { handleChange(e); }} checked={ type.replaceAll('\'', '').includes('phone') ? true : false } />
                      &nbsp;&nbsp;Smartphone
                  </div>  
                  <div>
                      <input type="checkbox" value="monitor" className="type" id="monitor" onChange={(e) => { handleChange(e); }} checked={ type.replaceAll('\'', '').includes('monitor') ? true : false } />
                      &nbsp;&nbsp;Monitor
                  </div>    
                  <div>
                      <input type="checkbox" value="tv" className="type" id="tv" onChange={(e) => { handleChange(e); }} checked={ type.replaceAll('\'', '').includes('tv') ? true : false } />
                      &nbsp;&nbsp;TV
                  </div> 
                  <div>
                      <input type="checkbox" value="graphicCard" className="type" id="graphicCard" onChange={(e) => { handleChange(e); }} checked={ type.replaceAll('\'', '').includes('graphicCard') ? true : false } />
                      &nbsp;&nbsp;Graphic Card
                  </div>  
                  <div>
                      <input type="checkbox" value="harddrive" className="type" id="harddrive" onChange={(e) => { handleChange(e); }} checked={ type.replaceAll('\'', '').includes('harddrive') ? true : false } />
                      &nbsp;&nbsp;Hard Drive
                  </div> 
                  <div>
                      <input type="checkbox" value="inputDevice" className="type" id="inputDevice" onChange={(e) => { handleChange(e); }} checked={ type.replaceAll('\'', '').includes('inputDevice') ? true : false } />
                      &nbsp;&nbsp;Keyboard & Mouse
                  </div> 
                  <div>
                      <input type="checkbox" value="cpu" className="type" id="cpu" onChange={(e) => { handleChange(e); }} checked={ type.replaceAll('\'', '').includes('cpu') ? true : false }  />
                      &nbsp;&nbsp;CPU
                  </div> 
                  <div>
                      <input type="checkbox" value="memory" className="type" id="memory" onChange={(e) => { handleChange(e); }} checked={ type.replaceAll('\'', '').includes('memory') ? true : false }  />
                      &nbsp;&nbsp;Memory
                  </div> 
                  <div>
                      <input type="checkbox" value="printer" className="type" id="printer" onChange={(e) => { handleChange(e); }} checked={ type.replaceAll('\'', '').includes('printer') ? true : false } />
                      &nbsp;&nbsp;Printer
                  </div> 
                  <div>
                      <input type="checkbox" value="projector" className="type" id="projector" onChange={(e) => { handleChange(e); }} checked={ type.replaceAll('\'', '').includes('projector') ? true : false } />
                      &nbsp;&nbsp;Projector
                  </div> 
                  <div>
                      <input type="checkbox" value="camera" className="type" id="camera" onChange={(e) => { handleChange(e); }} checked={ type.replaceAll('\'', '').includes('camera') ? true : false }  />
                      &nbsp;&nbsp;Camera
                  </div> 
                  <div>
                      <input type="checkbox" value="surveillance" className="type" id="surveillance" onChange={(e) => { handleChange(e); }} checked={ type.replaceAll('\'', '').includes('surveillance') ? true : false } />
                      &nbsp;&nbsp;Surveillance
                  </div> 
                  <div>
                      <input type="checkbox" value="accessory" className="type" id="accessory" onChange={(e) => { handleChange(e); }} checked={ type.replaceAll('\'', '').includes('accessory') ? true : false }  />
                      &nbsp;&nbsp;Accessory
                  </div>                                                                  
                </div>

                <br />
                <div className="optionTitle subTypeTitle" style={{ display: titleDisplay.includes('subTypeTitle') ? 'block' : 'none' }}>Sub Type</div>
                <div className="productsDropdown subTypeDropdown" id="myDropdownSubType"></div> 
                <br />
                <div className="optionTitle">Brand</div>
                <div className="productsDropdown" id="myDropdown3"> 
                    {brands.map((bran) => (                
                        <div>
                            <input type="checkbox" value={bran.ManufacturerGlobalDescr} className="brand" id={bran.ManufacturerGlobalDescr} 
                            onChange={(e) => { handleChange(e); }} checked={ brand == bran.MGD ? true : false } />&nbsp;&nbsp;{bran.MGD}
                        </div>   
                    ))}                                
                </div> 
                <br />
                <div className="optionTitle processorTitle" style={{ display: titleDisplay.includes('processorTitle') ? 'block' : 'none' }}>Processor</div>
                <div className="productsDropdown processorDropdown" id="myDropdown6"> 
                  <div>
                      <input type="checkbox" value="selectAll" className="processor" id="selectAll" onChange={(e) => { handleChange(e); }} 
                        checked={ procValue.includes('selectAll') ? true : false } />
                      &nbsp;&nbsp;Clear All
                  </div>
                  <div>
                      <input type="checkbox" value="i3" className="processor" id="i3" onChange={(e) => { handleChange(e); }} checked={ procValue.includes('i3') ? true : false } />
                      &nbsp;&nbsp;i3
                  </div>
                  <div>
                      <input type="checkbox" value="i5" className="processor" id="i5" onChange={(e) => { handleChange(e); }} checked={ procValue.includes('i5') ? true : false } />
                      &nbsp;&nbsp;i5
                  </div>
                  <div>
                      <input type="checkbox" value="i7" className="processor" id="i7" onChange={(e) => { handleChange(e); }} checked={ procValue.includes('i7') ? true : false } />
                      &nbsp;&nbsp;i7
                  </div>
                  <div>
                      <input type="checkbox" value="i9" className="processor" id="i9" onChange={(e) => { handleChange(e); }} checked={ procValue.includes('i9') ? true : false } />
                      &nbsp;&nbsp;i9
                  </div>
                  <div>
                      <input type="checkbox" value="CELERON" className="processor" id="CELERON" onChange={(e) => { handleChange(e); }} checked={ procValue.includes('CELERON') ? true : false } />
                      &nbsp;&nbsp;Celeron
                  </div>
                  <div>
                      <input type="checkbox" value="XEON" className="processor" id="XEON" onChange={(e) => { handleChange(e); }} checked={ procValue.includes('XEON') ? true : false } />
                      &nbsp;&nbsp;Xeon
                  </div>
                  <div>
                      <input type="checkbox" value="AMD" className="processor" id="AMD" onChange={(e) => { handleChange(e); }} checked={ procValue.includes('AMD') ? true : false } />
                      &nbsp;&nbsp;AMD
                  </div>                                     
                </div> 
                <br />
                <div className="optionTitle ramTitle" style={{ display: titleDisplay.includes('ramTitle') ? 'block' : 'none' }}>RAM</div>
                <div className="productsDropdown ramDropdown" id="myDropdown5">  
                    <div>
                        <input type="checkbox" value="selectAll" className="ram" id="selectAll_ram" onChange={(e) => { handleChange(e); }} checked={ ramValue.includes('selectAll') ? true : false } />
                        &nbsp;&nbsp;Clear All
                    </div>

                    <div>
                        <input type="checkbox" value="4GB" className="ram" id="4GB" onChange={(e) => { handleChange(e); }} checked={ ramValue.includes('4GB') ? true : false } />
                        &nbsp;&nbsp;4 GB
                    </div>

                    <div>
                        <input type="checkbox" value="8GB" className="ram" id="8GB" onChange={(e) => { handleChange(e); }} checked={ ramValue.includes('8GB') ? true : false } />
                        &nbsp;&nbsp;8 GB
                    </div>

                    <div>
                        <input type="checkbox" value="16GB" className="ram" id="16GB" onChange={(e) => { handleChange(e); }} checked={ ramValue.includes('16GB') ? true : false } />
                        &nbsp;&nbsp;16 GB
                    </div>
                    <div>
                        <input type="checkbox" value="32GB" className="ram" id="32GB" onChange={(e) => { handleChange(e); }} checked={ ramValue.includes('32GB') ? true : false } />
                        &nbsp;&nbsp;32 GB
                    </div>
                    <div>
                        <input type="checkbox" value="64GB" className="ram" id="64GB" onChange={(e) => { handleChange(e); }} checked={ ramValue.includes('64GB') ? true : false } />
                        &nbsp;&nbsp;64 GB
                    </div>                                     
                </div>  
                <br />
                <div className="optionTitle osTitle" style={{ display: titleDisplay.includes('osTitle') ? 'block' : 'none' }}>OS</div>
                <div className="productsDropdown osDropdown" id="myDropdown57">
                    <div>
                        <input type="radio" id="macos" className="itemOS" name="os" value="macos" onChange={(e) => { handleChange(e); }} checked={ osValue.includes('macos') ? true : false }/>
                        &nbsp;&nbsp;Mac
                    </div>
                    <div>
                        <input type="radio" id="chromeos" className="itemOS" name="os" value="chromeos" onChange={(e) => { handleChange(e); }} checked={ osValue.includes('chromeos') ? true : false } />
                        &nbsp;&nbsp;Chrome OS
                    </div>
                    <div>
                        <input type="radio" id="windows" className="itemOS" name="os" value="windows" onChange={(e) => { handleChange(e); }} checked={ osValue.includes('windows') ? true : false } />
                        &nbsp;&nbsp;Windows
                    </div> 
                    <div>
                        <input type="radio" id="allos" className="itemOS" name="os" value="allos" onChange={(e) => { handleChange(e); }} checked={ osValue.includes('allos') ? true : false } />
                        &nbsp;&nbsp;All
                    </div> 
                </div> 
                <br />
                <div className="optionTitle conditionTitle" style={{ display: titleDisplay.includes('conditionTitle') ? 'block' : 'none' }}>Condition</div>
                <div className="productsDropdown" id="myDropdown56">
                    <div>
                      <input type="radio" id="new" className="itemCondition" name="onClickItemCondition" value="new" onChange={(e) => { handleChange(e); }} checked={ conValue.includes('new') ? true : false } />
                      &nbsp;&nbsp;New
                    </div>
                    <div>
                      <input type="radio" id="refurbished" className="itemCondition" name="condition" value="refurbished" onChange={(e) => { handleChange(e); }} checked={ conValue.includes('refurbished') ? true : false } />
                      &nbsp;&nbsp;Refurbished
                    </div> 
                    <div>
                      <input type="radio" id="allCondition" className="itemCondition" name="condition" value="allCondition" onChange={(e) => { handleChange(e); }} checked={ conValue.includes('all') ? true : false } />
                      &nbsp;&nbsp;All
                    </div> 
                </div> 

                <br />
                <div className="optionTitle priceTitle" style={{ display: titleDisplay.includes('priceTitle') ? 'block' : 'none' }}>Price</div>
                <div className="productsDropdown" id="myDropdown4">  
                    {prices.map((price) => (                
                        <div>
                            <input type="checkbox" className="prices" id={price.priceRangeId} onChange={(e) => { handleChange(e); }} />
                            &nbsp;&nbsp;{price.priceRangeText} 
                        </div>    
                    ))}                               
                    <div>
                        <input type='number' style={{fontSize: '12px'}} id='minprice' name='minprice' placeholder='Min' min='0' max='100000' 
                        onKeyDown={(e) => { handleChange(e); }} />&nbsp;&nbsp;
                        <input type='number' style={{fontSize: '12px'}} id='maxprice' name='maxprice' placeholder='Max' min='0' max='100000'
                        onKeyDown={(e) => { handleChange(e); }} onFocusOut='getProductsForPrice();' />
                    </div>
                </div>  

                <br />
                <div className="optionTitle sortTitle" style={{ display: titleDisplay.includes('sortTitle') ? 'block' : 'none' }}>Sort by</div>
                <div className="productsDropdown" id="myDropdown11"> 
                    <div>
                      <input type="radio" id="Hot" className="itemSort" name="sortBy" value="Hot" onChange={(e) => { handleChange(e); }} checked={ sortValue.includes('Hot') ? true : false } />
                      &nbsp;&nbsp;Newly Added
                    </div>
                    <div>
                      <input type="radio" id="L2Hprice" className="itemSort" name="sortBy" value="L2Hprice" onChange={(e) => { handleChange(e); }} checked={ sortValue.includes('L2Hprice') ? true : false } />
                      &nbsp;&nbsp;Price: Low to High
                    </div>
                    <div>
                      <input type="radio" id="H2Lprice" className="itemSort" name="sortBy" value="H2Lprice" onChange={(e) => { handleChange(e); }} checked={ sortValue.includes('H2Lprice') ? true : false } />
                      &nbsp;&nbsp;Price: High to Low
                    </div>
                </div> 
            </div>
            <div className="itemPanel">     
              <img src={itemPanelBannerSrc} id="itemPanelBanner" className="itemPanelBanner" 
              category={itemPanelBannerCategory} onclick="showCategoryTopDeals($(this).attr('category'))" />     
              <div className="products-flex-container" dangerouslySetInnerHTML={rawMarkup()} />     
              
              <div style={{display: 'flex', justifyContent: 'center', alignItems: 'center'}}> 
                  <div style={{color: '#769e2d', fontSize: '18px', fontWeight: 'bold', padding: '10px', background: 'white'}}> 
                        <div id="pagination" className='pagination' onChange={(e) => { handleChange(e); }}> 
                            <Pagination
                                className="pagination-bar"
                                currentPage={currentPage}
                                totalCount={dataLength}
                                pageSize={PageSize}
                                onPageChange={page => setCurrentPage(page)} 
                            />
                        </div>
                  </div>
              </div> 
            </div> 
        </div>
    );
}; 
 
function getWindowDimensions() {
    const { innerWidth: wWidth, innerHeight: height } = window;
    return {
      wWidth,
      height
    };
  }
  
  function useWindowDimensions() {
    const [windowDimensions, setWindowDimensions] = useState(getWindowDimensions());
  
    useEffect(() => {
      function handleResize() {
        setWindowDimensions(getWindowDimensions());
      }
  
      window.addEventListener("resize", handleResize);
      return () => window.removeEventListener("resize", handleResize);
    }, []);
  
    return windowDimensions;
  }

export default Products;