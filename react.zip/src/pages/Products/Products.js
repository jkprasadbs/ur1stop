import "./Products.css";
import axios from "axios";
import {useState, useEffect } from "react"; 
import {useParams, Link} from "react-router-dom"; 
import {isMobile} from 'react-device-detect';
 
const Products = () => 
{
    const [products, setProducts] = useState([]);                                       const [total, setTotal] = useState(0);
    const { height, wWidth } = useWindowDimensions();                                   const params = useParams();

    const [titleDisplay, setTitleDisplay] = useState('');                    const [itemPanelBannerSrc, setItemPanelBannerSrc] = useState('');
    const [itemPanelBannerCategory, setItemPanelBannerCategory] = useState('');

    const [brandHtmlValue, setBrandHtml] = useState('');                              const [subTypeHtmlValue, setSubTypeHtml] = useState('');
    const [typeValue, setTypeValue] = useState('');                                   const [procValue, setProcValue] = useState('');
    const [ramValue, setRamValue] = useState('');                                     const [osValue, setOsValue] = useState('');
    const [conValue, setConValue] = useState('');                                     const [sortValue, setSortValue] = useState('');

    const [page, setPage] = useState(1);          const [type, setType] = useState('');         const [brand, setBrand] = useState('');
    const [thisType, setThisType] = useState(''); const [minPrice, setMinPrice] = useState(''); const [maxPrice, setMaxPrice] = useState('');
    const [sortBy, setSortBy] = useState('');     const [cpu, setCPU] = useState('');           const [ram, setRAM] = useState(''); 
    const [keyword, setKeyword] = useState('');   const [itemCondition, setItemCondition] = useState(''); 
    const [appleWindows, setAppleWindows] = useState('');   const [rentalSearch, setRentalSearch] = useState(''); 
    const [subType, setSubType] = useState('');       

    const getProducts = async () => 
    { 
        const { innerWidth: width, innerHeight: height } = window; 
        var tParams = params.id; /* .substring(1, params.id.length); */                      var paramArray = tParams.split('&'), jsonData;
        for(var i = 0; i < paramArray.length; i++)
        {
            var singleParamArray = paramArray[i].split('=');
            if(singleParamArray[0] == 'page')           { setPage(singleParamArray[1]); }
            if(singleParamArray[0] == 'type')           { setType(singleParamArray[1]); }
            if(singleParamArray[0] == 'subType')        { setSubType(singleParamArray[1]); }
            if(singleParamArray[0] == 'brand')          { setBrand(singleParamArray[1]); }
            if(singleParamArray[0] == 'minPrice')       { setMinPrice(singleParamArray[1]); }
            if(singleParamArray[0] == 'maxPrice')       { setMaxPrice(singleParamArray[1]); }
            if(singleParamArray[0] == 'sortBy')         { setSortBy(singleParamArray[1]); }
            if(singleParamArray[0] == 'cpu')            { setCPU(singleParamArray[1]); }
            if(singleParamArray[0] == 'ram')            { setRAM(singleParamArray[1]); }
            if(singleParamArray[0] == 'keyword')        { setKeyword(singleParamArray[1]); }
            if(singleParamArray[0] == 'itemCondition')  { setItemCondition(singleParamArray[1]); }
            if(singleParamArray[0] == 'appleWindows')   { setAppleWindows(singleParamArray[1]); }
            if(singleParamArray[0] == 'rentalSearch')   { setRentalSearch(singleParamArray[1]); }
            if(singleParamArray[0] == 'thisType')       { setThisType(singleParamArray[1]); } 
        } 

        var url = `http://127.0.0.1/products_test.php?page=${page}&type=${type}&brand=${brand}&thisType=${thisType}&minPrice=${minPrice}&maxPrice=${maxPrice}&sortBy=${sortBy}&cpu=${cpu}&ram=${ram}&keyword=${keyword}&itemCondition=${itemCondition}&appleWindows=${appleWindows}&rentalSearch=${rentalSearch}&width=${width}&subType=${subType}`;
        console.log('page products url ' +  url);                                       const { data } = await axios.get(url);         
        var splitData = data.split("|||");                                              jsonData = splitData[0].trim();    
        setProducts(splitData[1].trim());                                               setTotal(jsonData.Total);

        var tDisplay = 'keywordTitleproductTitleconditionTitlepriceTitlesortTitleprocessorTitleramTitleosTitleprocessorDropdownramDropdownosDropdown'; 
        if(type.indexOf("'gaming'") > -1 || type.indexOf("'notebook'") > -1 || type.indexOf("'desktop'") > -1 || type.indexOf("'tablet'") > -1 
        || type.indexOf("'aio'") > -1) { }   
        else { setCPU(''); setRAM(''); setAppleWindows(''); tDisplay = 'keywordTitleproductTitleconditionTitlepriceTitlesortTitle'; } 
         
        if(type.indexOf("'notebook'") > -1   || type.indexOf("'desktop'") > -1        || type.indexOf("'tablet'") > -1     || type.indexOf("'monitor'") > -1
        || type.indexOf("'tv'") > -1         || type.indexOf("'gamingConsole'") > -1  || type.indexOf("'harddrive'") > -1  || type.indexOf("'inputDevice'") > -1
        || type.indexOf("'cpu'") > -1        || type.indexOf("'inputDevice'") > -1    || type.indexOf("'memory'") > -1     || type.indexOf("'printer'") > -1
        || type.indexOf("'projector'") > -1  || type.indexOf("'accessory'") > -1      || type.indexOf("'videoGames'") > -1 || type.indexOf("'graphicCard'") > -1
        || type.indexOf("'accessory'") > -1) 
        {                
            console.log("products.js showResults newType contains 'notebook' || 'desktop' || 'tablet' || 'monitor' || 'tv' || 'gamingConsole'");                               
            tDisplay =  tDisplay + 'subTypeTitlesubTypeDropdown';
        } else { setSubType(''); }  

        setTitleDisplay(tDisplay);  

        setItemPanelBannerSrc('https://www.ur1stop.com/images/banners/promo3.jpg');

        if(!isMobile) 
        { 
            if(type == '')
            {
                //$('.productTitle').show(); $('#myDropdown150').show(); 
                if(brand == "'APPLE'")
                { setItemPanelBannerSrc('https://www.ur1stop.com/images/topDeals/refurbBanner.png'); setItemPanelBannerCategory('refurbApple'); } 

                if(itemCondition == 'refurbished')
                { setItemPanelBannerSrc('https://www.ur1stop.com/images/topDeals/refurbBanner.png'); setItemPanelBannerCategory('refurbWindows'); }
            }
            else
            { 
                if(type == "'notebook'")
                { setItemPanelBannerSrc('https://www.ur1stop.com/images/topDeals/notebookBanner.png'); setItemPanelBannerCategory('notebook'); }

                if(type == "'desktop'")
                { setItemPanelBannerSrc('https://www.ur1stop.com/images/topDeals/desktopBanner.png'); setItemPanelBannerCategory('desktop'); }
                
                if(type == "'aio'")
                { setItemPanelBannerSrc('https://www.ur1stop.com/images/topDeals/aioBanner.png'); setItemPanelBannerCategory('aio'); }

                if(type == "'monitor'")
                { setItemPanelBannerSrc('https://www.ur1stop.com/images/topDeals/monitorBanner.png'); setItemPanelBannerCategory('monitor'); }

                if(type == "'accessory'")
                { setItemPanelBannerSrc('https://www.ur1stop.com/images/topDeals/accessoryBanner.png'); setItemPanelBannerCategory('accessory'); }
                
                if(type == "'tv'")
                { setItemPanelBannerSrc('https://www.ur1stop.com/images/topDeals/tvBanner.png'); setItemPanelBannerCategory('tv'); }

                if(type == "'tablet'")
                { setItemPanelBannerSrc('https://www.ur1stop.com/images/topDeals/tabletBanner.png'); setItemPanelBannerCategory('tablet'); }

                if(type == "'gaming'")
                { setItemPanelBannerSrc('https://www.ur1stop.com/images/banners/gamingBanner.png'); setItemPanelBannerCategory('gaming'); }

                if(type == "'graphicCard'")
                { setItemPanelBannerSrc('https://www.ur1stop.com/images/topDeals/accessoryBanner.png'); setItemPanelBannerCategory('graphicCard'); }

                if(type == "'phone'")
                { setItemPanelBannerSrc('https://ur1stop.com/images/ruaa/tMobileBanner.png'); setItemPanelBannerCategory('phone'); }
            } 
        }        
    };

    useEffect(() => 
    {    
        getProducts();                             
        function handleResize() { getProducts(); }   
        window.addEventListener("resize", handleResize);
        return () => window.removeEventListener("resize", handleResize);
    }, []);       
     
    const handleChange = (e) => {
    };

    const rawMarkup = () => { return { __html: products }; }; 
    return (  
        <div className="container">
             <div className="optionPanel">  
                <div className="closeOption" onclick="hideMobileMenu();">X</div>
                <div className="optionTitle mobileMainMainLink" onclick="showMobileMenu(1);">Main Menu</div>
                <div id="deviceCategory" className="optionTitle keywordTitle" style={{position: 'relative', display: 'none' }}></div> 
                <div className="optionTitle productTitle" style={{ display: titleDisplay.includes('productTitle') ? 'display' : 'none' }}>Type</div>
                <div className="productsDropdown" id="myDropdown150">   
                  <div>
                      <input type="checkbox" value="selectAll" className="type" id="selectAllType" onChange={(e) => { handleChange(e); }} checked={ typeValue.includes('selectAll') ? 'true' : 'false' } />
                      &nbsp;&nbsp;Clear All
                  </div>
                  <div>
                      <input type="checkbox" value="gaming" className="type" id="gaming" onChange={(e) => { handleChange(e); }} checked={ typeValue.includes('gaming') ? 'true': 'false' } />
                      &nbsp;&nbsp;Gaming Computer
                  </div>
                  <div>
                      <input type="checkbox" value="gamingConsole" className="type" id="gamingConsole" onChange={(e) => { handleChange(e); }} checked={ typeValue.includes('gamingConsole') ? 'true': 'false' } />
                      &nbsp;&nbsp;Gaming Console
                  </div> 
                  <div>
                      <input type="checkbox" value="videoGames" className="type" id="videoGames" onChange={(e) => { handleChange(e); }} checked={ typeValue.includes('videoGames') ? 'true': 'false' } />
                      &nbsp;&nbsp;Video Games
                  </div> 
                  <div>
                      <input type="checkbox" value="notebook" className="type"  id="notebook" onChange={(e) => { handleChange(e); }} checked={ typeValue.includes('otebook') ? 'true': 'false' } />
                      &nbsp;&nbsp;Notebook
                  </div>
                  <div>
                      <input type="checkbox" value="desktop" class="type" id="desktop" onChange={(e) => { handleChange(e); }} checked={ typeValue.includes('desktop') ? 'true': 'false' } />
                      &nbsp;&nbsp;Desktop
                  </div>  
                  <div>
                      <input type="checkbox" value="aio" className="type" id="aio" onChange={(e) => { handleChange(e); }} checked={ typeValue.includes('aio') ? 'true': 'false' } />
                      &nbsp;&nbsp;All in one
                  </div> 
                  <div>
                      <input type="checkbox" value="tablet" className="type" id="tablet" onChange={(e) => { handleChange(e); }} checked={ typeValue.includes('tablet') ? 'true': 'false' } />
                      &nbsp;&nbsp;Tablet
                  </div> 
                  <div>
                      <input type="checkbox" value="phone" className="type" id="phone" onChange={(e) => { handleChange(e); }} checked={ typeValue.includes('phone') ? 'true': 'false' } />
                      &nbsp;&nbsp;Smartphone
                  </div>  
                  <div>
                      <input type="checkbox" value="monitor" className="type" id="monitor" onChange={(e) => { handleChange(e); }} checked={ typeValue.includes('monitor') ? 'true': 'false' } />
                      &nbsp;&nbsp;Monitor
                  </div>    
                  <div>
                      <input type="checkbox" value="tv" className="type" id="tv" onChange={(e) => { handleChange(e); }} checked={ typeValue.includes('tv') ? 'true': 'false' } />
                      &nbsp;&nbsp;TV
                  </div> 
                  <div>
                      <input type="checkbox" value="graphicCard" className="type" id="graphicCard" onChange={(e) => { handleChange(e); }} checked={ typeValue.includes('graphicCard') ? 'true': 'false' } />
                      &nbsp;&nbsp;Graphic Card
                  </div>  
                  <div>
                      <input type="checkbox" value="harddrive" className="type" id="harddrive" onChange={(e) => { handleChange(e); }} checked={ typeValue.includes('harddrive') ? 'true': 'false' } />
                      &nbsp;&nbsp;Hard Drive
                  </div> 
                  <div>
                      <input type="checkbox" value="inputDevice" className="type" id="inputDevice" onChange={(e) => { handleChange(e); }} checked={ typeValue.includes('inputDevice') ? 'true': 'false' } />
                      &nbsp;&nbsp;Keyboard & Mouse
                  </div> 
                  <div>
                      <input type="checkbox" value="cpu" className="type" id="cpu" onChange={(e) => { handleChange(e); }} checked={ typeValue.includes('cpu') ? 'true': 'false' }  />
                      &nbsp;&nbsp;CPU
                  </div> 
                  <div>
                      <input type="checkbox" value="memory" className="type" id="memory" onChange={(e) => { handleChange(e); }} checked={ typeValue.includes('memory') ? 'true': 'false' }  />
                      &nbsp;&nbsp;Memory
                  </div> 
                  <div>
                      <input type="checkbox" value="printer" className="type" id="printer" onChange={(e) => { handleChange(e); }} checked={ typeValue.includes('printer') ? 'true': 'false' } />
                      &nbsp;&nbsp;Printer
                  </div> 
                  <div>
                      <input type="checkbox" value="projector" className="type" id="projector" onChange={(e) => { handleChange(e); }} checked={ typeValue.includes('projector') ? 'true': 'false' } />
                      &nbsp;&nbsp;Projector
                  </div> 
                  <div>
                      <input type="checkbox" value="camera" className="type" id="camera" onChange={(e) => { handleChange(e); }} checked={ typeValue.includes('camera') ? 'true': 'false' }  />
                      &nbsp;&nbsp;Camera
                  </div> 
                  <div>
                      <input type="checkbox" value="surveillance" className="type" id="surveillance" onChange={(e) => { handleChange(e); }} checked={ typeValue.includes('surveillance') ? 'true': 'false' } />
                      &nbsp;&nbsp;Surveillance
                  </div> 
                  <div>
                      <input type="checkbox" value="accessory" className="type" id="accessory" onChange={(e) => { handleChange(e); }} checked={ typeValue.includes('accessory') ? 'true': 'false' }  />
                      &nbsp;&nbsp;Accessory
                  </div>                                                                  
                </div>

                <br />
                <div className="optionTitle subTypeTitle" style={{ display: titleDisplay.includes('subTypeTitle') ? 'display' : 'none' }}>Sub Type</div>
                <div className="productsDropdown subTypeDropdown" id="myDropdownSubType"></div> 
                <br />
                <div className="optionTitle">Brand</div>
                <div className="productsDropdown" id="myDropdown3"></div> 
                <br />
                <div className="optionTitle processorTitle" style={{ display: titleDisplay.includes('processorTitle') ? 'display' : 'none' }}>Processor</div>
                <div className="productsDropdown processorDropdown" id="myDropdown6"> 
                  <div>
                      <input type="checkbox" value="selectAll" className="processor" id="selectAll" onChange={(e) => { handleChange(e); }} checked={ procValue.includes('selectAll') ? 'true': 'false' } />
                      &nbsp;&nbsp;Clear All
                  </div>
                  <div>
                      <input type="checkbox" value="i3" className="processor" id="i3" onChange={(e) => { handleChange(e); }} checked={ procValue.includes('i3') ? 'true': 'false' } />
                      &nbsp;&nbsp;i3
                  </div>
                  <div>
                      <input type="checkbox" value="i5" className="processor" id="i5" onChange={(e) => { handleChange(e); }} checked={ procValue.includes('i5') ? 'true': 'false' } />
                      &nbsp;&nbsp;i5
                  </div>
                  <div>
                      <input type="checkbox" value="i7" className="processor" id="i7" onChange={(e) => { handleChange(e); }} checked={ procValue.includes('i7') ? 'true': 'false' } />
                      &nbsp;&nbsp;i7
                  </div>
                  <div>
                      <input type="checkbox" value="i9" className="processor" id="i9" onChange={(e) => { handleChange(e); }} checked={ procValue.includes('i9') ? 'true': 'false' } />
                      &nbsp;&nbsp;i9
                  </div>
                  <div>
                      <input type="checkbox" value="CELERON" className="processor" id="CELERON" onChange={(e) => { handleChange(e); }} checked={ procValue.includes('CELERON') ? 'true': 'false' } />
                      &nbsp;&nbsp;Celeron
                  </div>
                  <div>
                      <input type="checkbox" value="XEON" className="processor" id="XEON" onChange={(e) => { handleChange(e); }} checked={ procValue.includes('XEON') ? 'true': 'false' } />
                      &nbsp;&nbsp;Xeon
                  </div>
                  <div>
                      <input type="checkbox" value="AMD" className="processor" id="AMD" onChange={(e) => { handleChange(e); }} checked={ procValue.includes('AMD') ? 'true': 'false' } />
                      &nbsp;&nbsp;AMD
                  </div>                                     
                </div> 
                <br />
                <div className="optionTitle ramTitle" style={{ display: titleDisplay.includes('ramTitle') ? 'display' : 'none' }}>RAM</div>
                <div className="productsDropdown ramDropdown" id="myDropdown5">  
                    <div>
                        <input type="checkbox" value="selectAll" className="ram" id="selectAll_ram" onChange={(e) => { handleChange(e); }} checked={ ramValue.includes('selectAll') ? 'true': 'false' } />
                        &nbsp;&nbsp;Clear All
                    </div>

                    <div>
                        <input type="checkbox" value="4GB" className="ram" id="4GB" onChange={(e) => { handleChange(e); }} checked={ ramValue.includes('4GB') ? 'true': 'false' } />
                        &nbsp;&nbsp;4 GB
                    </div>

                    <div>
                        <input type="checkbox" value="8GB" className="ram" id="8GB" onChange={(e) => { handleChange(e); }} checked={ ramValue.includes('8GB') ? 'true': 'false' } />
                        &nbsp;&nbsp;8 GB
                    </div>

                    <div>
                        <input type="checkbox" value="16GB" className="ram" id="16GB" onChange={(e) => { handleChange(e); }} checked={ ramValue.includes('16GB') ? 'true': 'false' } />
                        &nbsp;&nbsp;16 GB
                    </div>
                    <div>
                        <input type="checkbox" value="32GB" className="ram" id="32GB" onChange={(e) => { handleChange(e); }} checked={ ramValue.includes('32GB') ? 'true': 'false' } />
                        &nbsp;&nbsp;32 GB
                    </div>
                    <div>
                        <input type="checkbox" value="64GB" className="ram" id="64GB" onChange={(e) => { handleChange(e); }} checked={ ramValue.includes('64GB') ? 'true': 'false' } />
                        &nbsp;&nbsp;64 GB
                    </div>                                     
                </div>  
                <br />
                <div className="optionTitle osTitle" style={{ display: titleDisplay.includes('osTitle') ? 'display' : 'none' }}>OS</div>
                <div className="productsDropdown osDropdown" id="myDropdown57">
                    <div>
                        <input type="radio" id="macos" className="itemOS" name="os" value="macos" onChange={(e) => { handleChange(e); }} checked={ osValue.includes('macos') ? 'true': 'false' }/>
                        &nbsp;&nbsp;Mac
                    </div>
                    <div>
                        <input type="radio" id="chromeos" className="itemOS" name="os" value="chromeos" onChange={(e) => { handleChange(e); }} checked={ osValue.includes('chromeos') ? 'true': 'false' } />
                        &nbsp;&nbsp;Chrome OS
                    </div>
                    <div>
                        <input type="radio" id="windows" className="itemOS" name="os" value="windows" onChange={(e) => { handleChange(e); }} checked={ osValue.includes('windows') ? 'true': 'false' } />
                        &nbsp;&nbsp;Windows
                    </div> 
                    <div>
                        <input type="radio" id="allos" className="itemOS" name="os" value="allos" onChange={(e) => { handleChange(e); }} checked={ osValue.includes('allos') ? 'true': 'false' } />
                        &nbsp;&nbsp;All
                    </div> 
                </div> 
                <br />
                <div className="optionTitle conditionTitle" style={{ display: titleDisplay.includes('conditionTitle') ? 'display' : 'none' }}>Condition</div>
                <div className="productsDropdown" id="myDropdown56">
                    <div>
                      <input type="radio" id="new" className="itemCondition" name="onClickItemCondition" value="new" onChange={(e) => { handleChange(e); }} checked={ conValue.includes('new') ? 'true': 'false' } />
                      &nbsp;&nbsp;New
                    </div>
                    <div>
                      <input type="radio" id="refurbished" className="itemCondition" name="condition" value="refurbished" onChange={(e) => { handleChange(e); }} checked={ conValue.includes('refurbished') ? 'true': 'false' } />
                      &nbsp;&nbsp;Refurbished
                    </div> 
                    <div>
                      <input type="radio" id="allCondition" className="itemCondition" name="condition" value="allCondition" onChange={(e) => { handleChange(e); }} checked={ conValue.includes('all') ? 'true': 'false' } />
                      &nbsp;&nbsp;All
                    </div> 
                </div> 

                <br />
                <div className="optionTitle priceTitle" style={{ display: titleDisplay.includes('priceTitle') ? 'display' : 'none' }}>Price</div>
                <div className="productsDropdown" id="myDropdown4"></div> 

                <br />
                <div className="optionTitle sortTitle" style={{ display: titleDisplay.includes('sortTitle') ? 'display' : 'none' }}>Sort by</div>
                <div className="productsDropdown" id="myDropdown11"> 
                    <div>
                      <input type="radio" id="Hot" className="itemSort" name="sortBy" value="macos" onChange={(e) => { handleChange(e); }} checked={ sortValue.includes('Hot') ? 'true': 'false' } />
                      &nbsp;&nbsp;Newly Added
                    </div>
                    <div>
                      <input type="radio" id="L2Hprice" className="itemSort" name="sortBy" value="macos" onChange={(e) => { handleChange(e); }} checked={ sortValue.includes('L2Hprice') ? 'true': 'false' } />
                      &nbsp;&nbsp;Price: Low to High
                    </div>
                    <div>
                      <input type="radio" id="H2Lprice" className="itemSort" name="sortBy" value="macos" onChange={(e) => { handleChange(e); }} checked={ sortValue.includes('H2Lprice') ? 'true': 'false' } />
                      &nbsp;&nbsp;Price: High to Low
                    </div>
                </div> 
            </div>
            <div className="itemPanel">     
              <img src={itemPanelBannerSrc} id="itemPanelBanner" className="itemPanelBanner" 
              category={itemPanelBannerCategory} onclick="showCategoryTopDeals($(this).attr('category'))" />     
              <div className="products-flex-container" dangerouslySetInnerHTML={rawMarkup()} />     
              
              <div style={{display: 'flex', justifyContent: 'center', alignItems: 'center'}}> 
                  <div style={{color: '#769e2d', fontSize: '18px', fontWeight: 'bold', padding: '10px', background: 'white'}}> 
                      <div id="pagination" className='pagination'></div>
                  </div>
              </div> 
            </div> 
        </div>
    );
}; 

function getWindowDimensions() {
    const { innerWidth: wWidth, innerHeight: height } = window;
    return {
      wWidth,
      height
    };
  }
  
  function useWindowDimensions() {
    const [windowDimensions, setWindowDimensions] = useState(getWindowDimensions());
  
    useEffect(() => {
      function handleResize() {
        setWindowDimensions(getWindowDimensions());
      }
  
      window.addEventListener("resize", handleResize);
      return () => window.removeEventListener("resize", handleResize);
    }, []);
  
    return windowDimensions;
  }

export default Products;