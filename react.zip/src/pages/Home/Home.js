import React, { useState, useEffect, useLayoutEffect, useRef } from "react"; 
import "./Home.css";
import Banner from "../../components/Banner/Banner";
import SpecialDeals from "../../components/SpecialDeals/SpecialDeals";
import TopDeals from "../../components/TopDeals/TopDeals";
import Reviews from "../../components/Reviews/Reviews";

function Home() { 
  const ref = useRef(); 
  const size = useDimensions(ref);
  var host = 'http://127/.0.0.1/', headerHeight;

  const handleResize = () => {
    console.log('home headerContentId height ' + document.getElementById('headerContentId').offsetHeight);  
    headerHeight = document.getElementById('aboveHeaderMenuContainerId').offsetHeight + document.getElementById('lineId').offsetHeight + document.getElementById('headerMenuId').offsetHeight;
    document.getElementById('bannerContainerId').style.top = headerHeight + 'px';    
  };

  useEffect(() => {    
    window.scroll(0, 0);
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  useLayoutEffect(() => {
    handleResize();
  }, []);

  return (
    <div ref={ref}>            
      <Banner />
      <SpecialDeals />
      <TopDeals />
      <Reviews />      
    </div>        
  );
}

function useDimensions(targetRef) {
  const getDimensions = () => {
    return {
      width: targetRef.current ? targetRef.current.offsetWidth : 0,
      height: targetRef.current ? targetRef.current.offsetHeight : 0
    };
  };

  const [dimensions, setDimensions] = useState(getDimensions);

  const handleResize = () => {
    setDimensions(getDimensions());
  };

  useEffect(() => {
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  useLayoutEffect(() => {
    handleResize();
  }, []);
  return dimensions;
}

export default Home;