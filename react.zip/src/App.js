import React, { useState, useEffect, useLayoutEffect, useRef } from "react"; 
import { BrowserRouter as Router, Route, Routes, useLocation } from "react-router-dom"; 
import "./App.css";
import Header from "./components/Header/Header";
import Footer from "./components/Footer/Footer";
import Home from "./pages/Home/Home";
import TopDeals from "./pages/TopDeals/TopDeals";
import Products from "./pages/Products/Products";
/* 
<BrowserRouter>
  <div className="app">
        <Container>
          <Switch>
            <Route path="/" component={Trending} exact />
            <Route path="/movies" component={Movies} />
            <Route path="/series" component={Series} />
            <Route path="/search" component={Search} />
          </Switch>
        </Container>
  </div>
  <SimpleBottomNavigation /> 
   </BrowserRouter> -->
*/
//import { Container } from "@material-ui/core";

//function App(props) {
const App = (props) => {

  /* const location = useLocation();
  const [locationState, setLocationState] = useState({id: 10});

  useEffect(() => 
  {      
      console.log('app ' + props.location.state.id);
      //console.log('app location ' + location); 
      if(location.props)
      {
          let _state = location.props;
          setLocationState(_state);
          //getTopDeals();    
      }
                      
      //function handleResize() { getTopDeals(); }   
      //window.addEventListener("resize", handleResize);
      //return () => window.removeEventListener("resize", handleResize);
  }, [location]);   */

  //console.log('app ' + locationState.id + ' ' +  props.location.state.id);

  return (           
    <>
      <Header />
      <Routes>                  
        <Route path="/" exact element={<Home />}></Route> 
        <Route path="/topDeals/:id" element={<TopDeals />}></Route>          
        <Route path="/products/:id" element={<Products />}></Route>          
      </Routes>
      <Footer />
    </> 
  );
}

export default App;