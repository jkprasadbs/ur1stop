import React, { useState, useEffect, useLayoutEffect, useRef } from "react"; 
import { BrowserRouter as Router, Route, Routes, useLocation } from "react-router-dom"; 
import "./App.css";
import Header from "./components/Header/Header";
import Footer from "./components/Footer/Footer";
import Home from "./pages/Home/Home";
import TopDeals from "./pages/TopDeals/TopDeals";
import Products from "./pages/Products/Products";
import PaginationTest from "./pages/Pagination/PaginationTest";
 
const App = (props) => {  
  return (           
    <>
      <Header />
      <Routes>                  
        <Route path="/" exact element={<Home />}></Route> 
        <Route path="/topDeals/:id" element={<TopDeals />}></Route>          
        <Route path="/products/:id" element={<Products />}></Route>     
        <Route path="/page" element={<PaginationTest />}></Route>          
      </Routes>
      <Footer />
    </> 
  );
}

export default App;